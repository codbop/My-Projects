// Class declaration with a method that has a parameter.
public class GradeBook
{
   // display a welcome message to the GradeBook user
   public void displayMessage( String courseName )
   {
      System.out.printf( "Welcome to the grade book for\n%s!\n", 
         courseName );
   } // end method displayMessage
} // end class GradeBook
