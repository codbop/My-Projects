// Creating a GradeBook object and calling its displayMessage method.
public class GradeBookTest
{
   // main method begins program execution
   public static void main( String[] args )
   { 
      // create a GradeBook object and assign it to myGradeBook
      GradeBook myGradeBook = new GradeBook(); 

      // call myGradeBook's displayMessage method
      myGradeBook.displayMessage(); 
   } // end main
} // end class GradeBookTest